import { useState, useEffect } from "react";
import {
  Search, FolderOpen, FileText, Sparkles, Briefcase, PieChart,
  ArrowRight, ChevronRight, MoreHorizontal, ArrowLeft, X, Plus,
  MapPin, Building2, Hash, Check, GripVertical, Download, Link, Trash2, CheckCircle2
} from "lucide-react";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: (string | undefined | null | false)[]) {
  return twMerge(clsx(inputs));
}

// ----------------------------------------------------------------------
// Main App Component
// ----------------------------------------------------------------------
export default function App() {
  const [view, setView] = useState<'home' | 'projects' | 'project-detail' | 'new-spec'>('home');
  
  return (
    <div className="min-h-screen bg-[#F9F9FB] text-foreground font-sans selection:bg-primary/20 flex flex-col">
      {/* Global Header */}
      <header className="flex items-center justify-between px-6 py-4 md:px-12 bg-[#F9F9FB]">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setView('home')}>
          <div className="w-5 h-5 rounded bg-foreground text-background flex items-center justify-center shadow-sm">
            <div className="w-2 h-2 border-[1.5px] border-background rounded-[2px]" />
          </div>
          <span className="font-medium text-foreground text-[14px] tracking-tight">EngiSpace</span>
        </div>
        <div className="flex items-center gap-5 text-[12px] font-medium text-muted-foreground">
          <button className="hover:text-foreground transition-colors">设置</button>
          <div className="w-6 h-6 rounded-full bg-border overflow-hidden ring-1 ring-black/5">
            <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64&h=64&fit=crop&auto=format" alt="User" />
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        {view === 'home' && <HomeView onNewSpec={() => setView('new-spec')} />}
        {view === 'new-spec' && <NewSpecWorkflow onExit={() => setView('home')} />}
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// Home View (Restored & Localized)
// ----------------------------------------------------------------------
function HomeView({ onNewSpec }: { onNewSpec: () => void }) {
  return (
    <main className="flex flex-col gap-10 animate-in fade-in duration-300 w-full max-w-5xl mx-auto px-6 py-4 md:px-12 md:py-8">
      
      {/* Command Bar */}
      <div className="relative group w-full">
        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
          <Search className="h-[16px] w-[16px] text-muted-foreground/60 group-focus-within:text-primary transition-colors" />
        </div>
        <input
          type="text"
          className="block w-full pl-10 pr-12 py-2.5 bg-white border border-black/[0.04] rounded-xl text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-[2px] focus:ring-primary/10 focus:border-primary/20 shadow-[0_1px_3px_rgba(0,0,0,0.01)] transition-all text-[14px]"
          placeholder="搜索项目、文档或功能..."
        />
        <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
          <span className="text-[10px] font-medium font-mono text-muted-foreground/60 border border-black/5 px-1.5 py-0.5 rounded bg-black/[0.02]">⌘K</span>
        </div>
      </div>

      {/* Spatial Layout: 3 + 2 */}
      <section className="flex flex-col gap-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <ActionCard 
            icon={<FileText size={18} className="text-primary" strokeWidth={2} />} 
            title="设计说明" 
            desc="起草并管理技术设计说明" 
            highlight 
            onClick={onNewSpec}
          />
          <ActionCard 
            icon={<PieChart size={18} strokeWidth={2} />} 
            title="可研报告" 
            desc="独立起草可行性研究报告" 
          />
          <ActionCard 
            icon={<Briefcase size={18} strokeWidth={2} />} 
            title="投标文件" 
            desc="准备和管理项目招投标文件" 
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <ActionCard 
            icon={<FolderOpen size={18} strokeWidth={2} />} 
            title="项目管理" 
            desc="组织与管理全局项目信息" 
            horizontal 
          />
          <ActionCard 
            icon={<Sparkles size={18} strokeWidth={2} />} 
            title="AI 工程助手" 
            desc="自动化文档校审与检查" 
            horizontal 
          />
        </div>
      </section>

      {/* Lists */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10 pt-2">
        {/* Active Projects */}
        <section className="flex flex-col gap-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-[12px] font-semibold text-muted-foreground uppercase tracking-wider">当前项目</h2>
            <button className="text-[12px] font-medium text-muted-foreground hover:text-foreground transition-colors flex items-center gap-0.5">
              查看全部 <ChevronRight size={14} />
            </button>
          </div>
          <div className="flex flex-col -mx-2">
            {[
              { name: "市南区跨河大桥 4B标段", id: "PRJ-2401", client: "市交通局", date: "2小时前" },
              { name: "机场 C 航站楼扩建", id: "PRJ-2405", client: "机场集团", date: "昨天" },
              { name: "12号公路立交", id: "PRJ-2399", client: "省交投", date: "3天前" }
            ].map((project, i) => (
              <div key={i} className="group flex items-center justify-between p-2.5 rounded-lg hover:bg-black/[0.03] transition-colors cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-md bg-white border border-black/[0.04] flex items-center justify-center text-foreground/60 shadow-[0_1px_2px_rgba(0,0,0,0.01)] group-hover:border-black/[0.08] transition-colors">
                    <FolderOpen size={15} strokeWidth={2} />
                  </div>
                  <div className="flex flex-col">
                    <h3 className="font-medium text-[14px] text-foreground leading-tight">{project.name}</h3>
                    <div className="flex items-center gap-1.5 text-[12px] text-muted-foreground mt-0.5">
                      <span>{project.id}</span>
                      <span className="text-black/10">•</span>
                      <span className="truncate max-w-[120px]">{project.client}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[12px] text-muted-foreground/70">{project.date}</span>
                  <button className="text-muted-foreground/40 hover:text-foreground opacity-0 group-hover:opacity-100 transition-all">
                    <MoreHorizontal size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Recent Work */}
        <section className="flex flex-col gap-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-[12px] font-semibold text-muted-foreground uppercase tracking-wider">最近工作</h2>
          </div>
          <div className="flex flex-col -mx-2">
            {[
              { title: "建筑专业设计说明 v2", type: "设计说明", project: "市南区跨河大桥 4B标段", date: "10:42 AM", icon: <FileText size={15} /> },
              { title: "环境影响可研分析", type: "可研报告", project: null, date: "昨天", icon: <PieChart size={15} /> },
              { title: "材料设备招标技术要求", type: "投标文件", project: "12号公路立交", date: "10月24日", icon: <Briefcase size={15} /> },
              { title: "规范符合性 AI 检查", type: "AI 校审", project: "机场 C 航站楼扩建", date: "10月22日", icon: <Sparkles size={15} /> }
            ].map((item, i) => (
              <div key={i} className="group flex items-center justify-between p-2.5 rounded-lg hover:bg-black/[0.03] transition-colors cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-md bg-white border border-black/[0.04] flex items-center justify-center text-foreground/60 shadow-[0_1px_2px_rgba(0,0,0,0.01)] group-hover:border-black/[0.08] transition-colors">
                    {item.icon}
                  </div>
                  <div className="flex flex-col">
                    <h3 className="font-medium text-[14px] text-foreground leading-tight">{item.title}</h3>
                    <div className="flex items-center gap-1.5 text-[12px] text-muted-foreground mt-0.5">
                      <span>{item.type}</span>
                      {item.project && (
                        <>
                          <span className="text-black/10">•</span>
                          <span className="truncate max-w-[120px]">{item.project}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <span className="text-[12px] text-muted-foreground/70">{item.date}</span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}


// ----------------------------------------------------------------------
// Workflow State Machine (New Spec)
// ----------------------------------------------------------------------
type SpecStep = '1-params' | '2a-template' | '2b-editor' | '3-preview';

function NewSpecWorkflow({ onExit }: { onExit: () => void }) {
  const [step, setStep] = useState<SpecStep>('1-params');
  
  // Minimalist Stepper
  const steps = [
    { id: '1-params', label: '参数设置', num: '01' },
    { id: '2a-template', label: '模板与章节', num: '02' },
    { id: '3-preview', label: '生成说明', num: '03' }
  ];

  const currentMainStepIndex = step === '1-params' ? 0 : step.startsWith('2') ? 1 : 2;

  return (
    <div className="flex-1 flex flex-col max-w-[1200px] w-full mx-auto pb-12 animate-in fade-in duration-300">
      
      {/* Light Stepper & Header */}
      <div className="flex items-center justify-between px-6 md:px-12 py-6">
        <div className="flex items-center gap-4">
          <button onClick={onExit} className="text-muted-foreground hover:text-foreground transition-colors p-1 -ml-1 rounded-md hover:bg-black/[0.03]">
            <X size={16} />
          </button>
          <h1 className="text-[16px] font-semibold text-foreground">新建设计说明</h1>
        </div>
        
        <div className="flex items-center gap-8">
          {steps.map((s, i) => {
            const isActive = i === currentMainStepIndex;
            const isPast = i < currentMainStepIndex;
            return (
              <div key={s.id} className="flex items-center gap-2">
                <span className={cn(
                  "text-[11px] font-mono font-medium px-1.5 py-0.5 rounded",
                  isActive ? "bg-foreground text-background" : isPast ? "text-foreground" : "text-muted-foreground/40"
                )}>
                  {s.num}
                </span>
                <span className={cn(
                  "text-[13px] font-medium transition-colors",
                  isActive ? "text-foreground" : isPast ? "text-foreground" : "text-muted-foreground/40"
                )}>
                  {s.label}
                </span>
                {i < steps.length - 1 && (
                  <span className="text-muted-foreground/20 ml-6">—</span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Dynamic Content based on step */}
      <div className="flex-1 px-6 md:px-12 flex flex-col mt-4">
        {step === '1-params' && <Step1Params onNext={() => setStep('2a-template')} />}
        {step === '2a-template' && <Step2ATemplate onSelect={() => setStep('2b-editor')} onBack={() => setStep('1-params')} />}
        {step === '2b-editor' && <Step2BEditor onNext={() => setStep('3-preview')} onBack={() => setStep('1-params')} />}
        {step === '3-preview' && <Step3Preview onEdit={() => setStep('2b-editor')} />}
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// Step 01: Parameters
// ----------------------------------------------------------------------
function Step1Params({ onNext }: { onNext: () => void }) {
  const [isLinked, setIsLinked] = useState(false);
  const [corrosion, setCorrosion] = useState('medium');

  return (
    <div className="max-w-3xl mx-auto w-full flex flex-col gap-12 animate-in fade-in slide-in-from-bottom-2 duration-300">
      
      {/* 1. Select Discipline */}
      <section className="flex flex-col gap-4">
        <h2 className="text-[14px] font-semibold text-foreground">专业</h2>
        <div className="flex items-center gap-2 bg-black/[0.02] p-1 rounded-[10px] w-fit border border-black/[0.03]">
          {['建筑', '结构', '给排水', '电气', '暖通', '其他'].map((d) => (
            <button
              key={d}
              className={cn(
                "px-4 py-1.5 rounded-md text-[13px] font-medium transition-all",
                d === '结构' 
                  ? "bg-white text-foreground shadow-[0_1px_3px_rgba(0,0,0,0.04)] border border-black/[0.04]" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {d}
            </button>
          ))}
        </div>
      </section>

      {/* 2. Link Project */}
      <section className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-semibold text-foreground">关联项目 <span className="text-muted-foreground font-normal">(可选)</span></h2>
          {!isLinked && (
            <button onClick={() => setIsLinked(true)} className="flex items-center gap-1.5 text-[12px] font-medium text-primary hover:text-primary/80 transition-colors">
              <Link size={13} /> 关联已有项目
            </button>
          )}
        </div>

        {isLinked ? (
          <div className="bg-white rounded-xl border border-black/[0.04] p-5 shadow-[0_1px_2px_rgba(0,0,0,0.01)] flex flex-col gap-4 relative group">
            <button onClick={() => setIsLinked(false)} className="absolute top-4 right-4 text-muted-foreground/40 hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity">
              <X size={16} />
            </button>
            <div className="flex items-center gap-3 border-b border-black/[0.03] pb-4">
              <div className="w-8 h-8 rounded bg-primary/10 text-primary flex items-center justify-center">
                <FolderOpen size={15} strokeWidth={2} />
              </div>
              <div>
                <div className="text-[14px] font-medium">市南区跨河大桥 4B标段</div>
                <div className="text-[12px] text-muted-foreground">PRJ-2401</div>
              </div>
            </div>
            <div className="flex gap-12 text-[13px]">
              <div><span className="text-muted-foreground">建设单位：</span> 市交通局</div>
              <div><span className="text-muted-foreground">建设地点：</span> 市南区跨河核心段</div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            <InputGroup label="项目名称" placeholder="如果不关联项目，请在此输入..." />
            <InputGroup label="项目编号" placeholder="可选" />
            <InputGroup label="建设单位" placeholder="可选" />
            <InputGroup label="建设地点" placeholder="可选" />
          </div>
        )}
      </section>

      {/* 3. Structural Parameters */}
      <section className="flex flex-col gap-8">
        <h2 className="text-[14px] font-semibold text-foreground border-b border-black/[0.04] pb-2">结构专业参数</h2>
        
        {/* Basic Parameters */}
        <div className="flex flex-col gap-4">
          <h3 className="text-[12px] font-medium text-muted-foreground tracking-wide">基本设计参数</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <SelectGroup label="场地类别" value="II类" />
            <SelectGroup label="抗震设防类别" value="标准设防类" />
            <SelectGroup label="结构安全等级" value="二级" />
            <SelectGroup label="地基基础设计等级" value="乙级" />
          </div>
        </div>

        {/* Soil Corrosivity */}
        <div className="flex flex-col gap-4">
          <h3 className="text-[12px] font-medium text-muted-foreground tracking-wide">水土腐蚀性</h3>
          <textarea 
            className="w-full h-24 px-4 py-3 bg-white border border-black/[0.06] rounded-xl text-[13px] text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:border-primary/40 focus:ring-2 focus:ring-primary/10 transition-all shadow-[0_1px_2px_rgba(0,0,0,0.01)] resize-none"
            placeholder="请粘贴地勘报告中的水土腐蚀性结论……"
          ></textarea>
        </div>

        {/* Material & Anti-corrosion */}
        <div className="flex flex-col gap-4">
          <h3 className="text-[12px] font-medium text-muted-foreground tracking-wide">材料与防腐方案</h3>
          <div className="flex gap-3">
            <RadioCard active={corrosion === 'weak'} onClick={() => setCorrosion('weak')} label="弱腐蚀" />
            <RadioCard active={corrosion === 'medium'} onClick={() => setCorrosion('medium')} label="中腐蚀" />
            <RadioCard active={corrosion === 'strong'} onClick={() => setCorrosion('strong')} label="强腐蚀" />
          </div>
          
          <div className="mt-2 flex flex-col gap-2">
            <span className="text-[12px] text-foreground/80 mb-1">附加防腐措施 (可选)</span>
            <CheckboxItem label="混凝土保护层厚度增加 10mm" checked />
            <CheckboxItem label="基础表面涂刷防腐涂料" />
            <CheckboxItem label="采用抗硫酸盐水泥" />
          </div>
        </div>
      </section>

      {/* Footer Action */}
      <div className="flex justify-end pt-8 pb-16">
        <button onClick={onNext} className="flex items-center gap-2 bg-foreground text-background px-5 py-2.5 rounded-xl text-[13px] font-medium hover:bg-foreground/90 transition-all shadow-[0_2px_8px_rgba(0,0,0,0.08)] hover:-translate-y-0.5">
          下一步：选择模板 <ArrowRight size={15} />
        </button>
      </div>

    </div>
  );
}

// ----------------------------------------------------------------------
// Step 02A: Select Template
// ----------------------------------------------------------------------
function Step2ATemplate({ onSelect, onBack }: { onSelect: () => void, onBack: () => void }) {
  const templates = [
    { name: "框架结构", desc: "适用于常规钢筋混凝土框架结构建筑。" },
    { name: "水池结构", desc: "适用于各类水处理及储水池结构。" },
    { name: "水池 + 框架", desc: "适用于水池与框架混合结构。" },
    { name: "钢结构", desc: "适用于轻型或重型钢结构厂房及建筑。" },
    { name: "自定义组合", desc: "从空白开始，自由组合标准章节。" },
  ];

  return (
    <div className="max-w-4xl mx-auto w-full flex flex-col gap-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
      <button onClick={onBack} className="w-fit flex items-center gap-1.5 text-[13px] text-muted-foreground hover:text-foreground transition-colors -ml-1 px-1 py-0.5 rounded-md hover:bg-black/[0.03]">
        <ArrowLeft size={14} /> 返回参数设置
      </button>

      <div className="flex flex-col gap-2">
        <h2 className="text-[20px] font-semibold text-foreground">选择说明模板</h2>
        <p className="text-[13px] text-muted-foreground">模板提供了一套默认的章节结构。您可以在下一步中自由添加、删除或修改章节。</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
        {templates.map((t, i) => (
          <div key={i} onClick={onSelect} className="group flex flex-col p-5 bg-white rounded-2xl border border-black/[0.04] shadow-[0_1px_3px_rgba(0,0,0,0.01)] hover:border-black/[0.08] hover:shadow-[0_4px_16px_rgba(0,0,0,0.04)] cursor-pointer transition-all duration-300 hover:-translate-y-0.5">
            <div className="w-10 h-10 rounded-xl bg-black/[0.02] text-foreground/70 flex items-center justify-center mb-4 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
              <FileText size={18} strokeWidth={1.5} />
            </div>
            <h3 className="text-[14px] font-medium text-foreground">{t.name}</h3>
            <p className="text-[13px] text-muted-foreground mt-1.5 leading-relaxed">{t.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// Step 02B: Editor
// ----------------------------------------------------------------------
const MOCK_CHAPTERS = [
  { id: '1', title: '1. 设计依据', checked: true },
  { id: '2', title: '2. 工程概况', checked: true },
  { id: '3', title: '3. 结构设计', checked: true },
  { id: '4', title: '4. 地基基础', checked: true },
  { id: '5', title: '5. 材料要求', checked: true },
  { id: '6', title: '6. 施工说明', checked: false },
];

function Step2BEditor({ onNext, onBack }: { onNext: () => void, onBack: () => void }) {
  const [activeId, setActiveId] = useState('3');
  const [saved, setSaved] = useState(true);

  const handleInput = () => {
    setSaved(false);
    setTimeout(() => setSaved(true), 1000);
  };

  const confirmBack = () => {
    if (confirm("返回修改参数将根据新参数重新生成章节副本并覆盖当前修改，是否继续？")) {
      onBack();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] animate-in fade-in duration-300 border border-black/[0.04] rounded-[20px] overflow-hidden bg-white shadow-[0_2px_12px_rgba(0,0,0,0.02)]">
      
      {/* Toolbar */}
      <div className="h-12 flex items-center justify-between px-4 border-b border-black/[0.04] bg-[#FCFCFD]">
        <button onClick={confirmBack} className="flex items-center gap-1.5 text-[12px] font-medium text-muted-foreground hover:text-foreground transition-colors px-2 py-1 rounded hover:bg-black/[0.03]">
          <ArrowLeft size={14} /> 参数设置
        </button>
        <button onClick={onNext} className="flex items-center gap-1.5 text-[12px] font-medium bg-foreground text-background px-3 py-1.5 rounded-lg hover:bg-foreground/90 transition-all shadow-sm">
          生成说明 <ArrowRight size={14} />
        </button>
      </div>

      {/* Split View */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left: TOC */}
        <div className="w-[280px] border-r border-black/[0.04] bg-[#FCFCFD] flex flex-col">
          <div className="p-3 border-b border-black/[0.02]">
            <button className="w-full flex items-center justify-center gap-1.5 text-[12px] font-medium text-foreground border border-black/[0.05] bg-white px-2 py-1.5 rounded-lg shadow-[0_1px_2px_rgba(0,0,0,0.01)] hover:border-black/[0.1] transition-all">
              <Plus size={14} /> 添加章节
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-2 flex flex-col gap-1">
            {MOCK_CHAPTERS.map(ch => (
              <div 
                key={ch.id} 
                onClick={() => setActiveId(ch.id)}
                className={cn(
                  "group flex items-center justify-between px-2 py-2 rounded-lg cursor-pointer transition-colors",
                  activeId === ch.id ? "bg-black/[0.04]" : "hover:bg-black/[0.02]"
                )}
              >
                <div className="flex items-center gap-2 overflow-hidden">
                  <GripVertical size={14} className="text-muted-foreground/30 group-hover:text-muted-foreground cursor-grab shrink-0" />
                  <div className={cn("w-3.5 h-3.5 rounded-[4px] border flex items-center justify-center shrink-0 transition-colors", ch.checked ? "bg-foreground border-foreground text-background" : "border-black/20")}>
                    {ch.checked && <Check size={10} strokeWidth={3} />}
                  </div>
                  <span className={cn("text-[13px] truncate", ch.checked ? "text-foreground font-medium" : "text-muted-foreground/60")}>
                    {ch.title}
                  </span>
                </div>
                {activeId === ch.id && ch.checked && (
                  <button className="text-muted-foreground/40 hover:text-red-500 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Trash2 size={13} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Right: Plain Text Editor */}
        <div className="flex-1 flex flex-col relative bg-white">
          <div className="h-10 flex items-center justify-between px-8 border-b border-black/[0.02]">
             <div className="text-[11px] font-medium text-muted-foreground/60 flex items-center gap-1.5">
               {saved ? (
                 <><CheckCircle2 size={12} className="text-green-500/70" /> 已自动保存</>
               ) : (
                 <span className="animate-pulse">正在保存...</span>
               )}
             </div>
             <button className="text-[11px] font-medium text-muted-foreground hover:text-foreground transition-colors underline decoration-black/20 underline-offset-2">
               恢复本章默认内容
             </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-8 md:p-12">
            <div className="max-w-3xl mx-auto flex flex-col h-full">
              <h2 className="text-[22px] font-semibold text-foreground mb-6">3. 结构设计</h2>
              {/* Note: This is a structured plain text area. No rich text formatting. */}
              <textarea 
                className="flex-1 w-full text-[14px] leading-loose text-foreground/90 bg-transparent resize-none focus:outline-none placeholder:text-muted-foreground/30"
                defaultValue={`3.1 结构体系
本工程采用现钢筋混凝土框架结构。
楼盖体系采用现浇钢筋混凝土梁板结构。

3.2 荷载取值
(1) 楼面恒荷载：按建筑楼面做法计算。
(2) 楼面活荷载：
    - 办公区域：2.0 kN/m²
    - 走廊及楼梯：2.5 kN/m²
    - 设备用房：7.0 kN/m²

3.3 抗震构造措施
框架梁、柱的抗震构造措施严格按《建筑抗震设计规范》(GB 50011-2010) (2016年版) 中对应的抗震等级要求执行。

[Table Block Placeholder: Design Loads]
`}
                onChange={handleInput}
              />
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// Step 03: Preview
// ----------------------------------------------------------------------
function Step3Preview({ onEdit }: { onEdit: () => void }) {
  return (
    <div className="flex-1 flex flex-col animate-in fade-in duration-300">
      
      {/* Top Actions */}
      <div className="flex items-center justify-between mb-8 max-w-[800px] mx-auto w-full">
        <button onClick={onEdit} className="flex items-center gap-1.5 text-[13px] font-medium text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-lg border border-black/[0.04] bg-white shadow-sm hover:shadow">
          <ArrowLeft size={14} /> 重新配置
        </button>
        <button className="flex items-center gap-1.5 text-[13px] font-medium bg-foreground text-background px-4 py-1.5 rounded-lg hover:bg-foreground/90 transition-all shadow-[0_2px_8px_rgba(0,0,0,0.08)] hover:-translate-y-0.5">
          <Download size={14} /> 导出 Word
        </button>
      </div>

      {/* Document View */}
      <div className="bg-white max-w-[800px] mx-auto w-full min-h-[800px] border border-black/[0.04] shadow-[0_4px_24px_rgba(0,0,0,0.02)] rounded-sm p-12 md:p-20 mb-12">
        <div className="text-center mb-16">
          <h1 className="text-[24px] font-semibold text-foreground tracking-tight mb-2">市南区跨河大桥 4B标段 结构设计说明</h1>
          <p className="text-[13px] text-muted-foreground">PRJ-2401 · 市交通局</p>
        </div>

        <div className="flex flex-col gap-10 text-[14px] leading-relaxed text-foreground/90">
          <section>
            <h2 className="text-[16px] font-bold text-foreground mb-3">1. 设计依据</h2>
            <div className="whitespace-pre-wrap">
              1.1 建设单位提供的设计任务书及相关要求。
              1.2 相关国家标准及规范：
              - 《建筑结构可靠性设计统一标准》GB 50068-2018
              - 《建筑结构荷载规范》GB 50009-2012
              - 《混凝土结构设计规范》GB 50010-2010 (2015年版)
            </div>
          </section>

          <section>
            <h2 className="text-[16px] font-bold text-foreground mb-3">2. 工程概况</h2>
            <div className="whitespace-pre-wrap">
              2.1 建设地点：市南区跨河核心段。
              2.2 本工程为一类建筑，结构设计使用年限为50年。
              2.3 建筑结构安全等级为二级，地基基础设计等级为乙级。
            </div>
          </section>

          <section>
            <h2 className="text-[16px] font-bold text-foreground mb-3">3. 结构设计</h2>
            <div className="whitespace-pre-wrap">
              3.1 结构体系：本工程采用现钢筋混凝土框架结构。
              3.2 抗震设防：抗震设防烈度按当地标准取值，抗震设防类别为标准设防类(丙类)。
              3.3 楼盖体系采用现浇钢筋混凝土梁板结构。
            </div>
          </section>
          
          <div className="h-20" /> {/* Bottom breathing room */}
        </div>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// Tiny UI Components
// ----------------------------------------------------------------------
function InputGroup({ label, placeholder }: { label: string, placeholder: string }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] font-medium text-muted-foreground tracking-wide">{label}</label>
      <input 
        type="text" 
        placeholder={placeholder}
        className="w-full px-3 py-2 bg-white border border-black/[0.06] rounded-lg text-[13px] text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:border-primary/40 focus:ring-2 focus:ring-primary/10 transition-all shadow-[0_1px_2px_rgba(0,0,0,0.01)]"
      />
    </div>
  );
}

function SelectGroup({ label, value }: { label: string, value: string }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] font-medium text-muted-foreground tracking-wide">{label}</label>
      <div className="w-full px-3 py-2 bg-white border border-black/[0.06] rounded-lg text-[13px] text-foreground flex items-center justify-between cursor-pointer hover:border-black/[0.1] transition-colors shadow-[0_1px_2px_rgba(0,0,0,0.01)]">
        {value}
        <ChevronRight size={12} className="text-muted-foreground/50 rotate-90" />
      </div>
    </div>
  );
}

function RadioCard({ active, label, onClick }: { active: boolean, label: string, onClick: () => void }) {
  return (
    <div 
      onClick={onClick}
      className={cn(
        "flex-1 flex items-center justify-center py-2.5 rounded-lg border text-[13px] font-medium cursor-pointer transition-all",
        active 
          ? "border-primary bg-primary/5 text-primary shadow-sm" 
          : "border-black/[0.06] bg-white text-muted-foreground hover:text-foreground hover:border-black/[0.1] shadow-[0_1px_2px_rgba(0,0,0,0.01)]"
      )}
    >
      {label}
    </div>
  );
}

function CheckboxItem({ label, checked = false }: { label: string, checked?: boolean }) {
  const [isChecked, setIsChecked] = useState(checked);
  return (
    <div 
      onClick={() => setIsChecked(!isChecked)}
      className="flex items-center gap-2.5 group cursor-pointer w-fit"
    >
      <div className={cn(
        "w-3.5 h-3.5 rounded-[4px] border flex items-center justify-center transition-colors",
        isChecked ? "bg-foreground border-foreground text-background" : "bg-white border-black/20 group-hover:border-black/40"
      )}>
        {isChecked && <Check size={10} strokeWidth={3} />}
      </div>
      <span className={cn("text-[13px] transition-colors", isChecked ? "text-foreground" : "text-muted-foreground")}>{label}</span>
    </div>
  );
}

// ----------------------------------------------------------------------
// Reusable Action Card from Home
// ----------------------------------------------------------------------
function ActionCard({ 
  icon, 
  title, 
  desc, 
  highlight, 
  horizontal,
  onClick
}: { 
  icon: React.ReactNode, 
  title: string, 
  desc: string, 
  highlight?: boolean,
  horizontal?: boolean,
  onClick?: () => void
}) {
  if (horizontal) {
    return (
      <div onClick={onClick} className="group relative flex items-center p-3.5 gap-3.5 bg-white rounded-[14px] border border-black/[0.04] shadow-[0_1px_3px_rgba(0,0,0,0.02)] hover:border-black/[0.08] hover:shadow-[0_4px_12px_rgba(0,0,0,0.04)] cursor-pointer transition-all duration-200">
        <div className={cn(
          "w-9 h-9 flex-shrink-0 rounded-lg flex items-center justify-center transition-colors duration-200",
          highlight ? "bg-primary/10 text-primary" : "bg-black/[0.03] text-foreground/70 group-hover:bg-black/[0.06]"
        )}>
          {icon}
        </div>
        <div className="flex flex-col flex-grow overflow-hidden">
          <h3 className="font-medium text-foreground text-[14px] truncate leading-tight">{title}</h3>
          <p className="text-[12.5px] text-muted-foreground truncate mt-0.5">{desc}</p>
        </div>
        <div className="flex-shrink-0 pl-2">
          <ArrowRight size={14} className="text-muted-foreground/40 group-hover:text-foreground/80 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-200" />
        </div>
      </div>
    );
  }

  return (
    <div onClick={onClick} className="group relative flex flex-col p-4 gap-5 bg-white rounded-[14px] border border-black/[0.04] shadow-[0_1px_3px_rgba(0,0,0,0.02)] hover:border-black/[0.08] hover:shadow-[0_4px_12px_rgba(0,0,0,0.04)] cursor-pointer transition-all duration-200">
      <div className="flex items-start justify-between">
        <div className={cn(
          "w-9 h-9 rounded-lg flex items-center justify-center transition-colors duration-200",
          highlight ? "bg-primary/10 text-primary" : "bg-black/[0.03] text-foreground/70 group-hover:bg-black/[0.06]"
        )}>
          {icon}
        </div>
        <ArrowRight size={14} className="text-muted-foreground/40 group-hover:text-foreground/80 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-200 mt-1 mr-1" />
      </div>
      <div className="flex flex-col">
        <h3 className="font-medium text-foreground text-[14px] truncate leading-tight">{title}</h3>
        <p className="text-[12.5px] text-muted-foreground truncate mt-1">{desc}</p>
      </div>
    </div>
  );
}
