import React, { useState } from 'react';
import { 
  X, 
  LayoutTemplate, 
  CheckCircle2, 
  Settings2,
  MapPin
} from 'lucide-react';

export default function App() {
  const [selectedFormat, setSelectedFormat] = useState('A1');
  const [scale, setScale] = useState('1x');

  return (
    <div className="min-h-screen bg-neutral-900 flex items-center justify-center p-4">
      {/* Dialog Container - Made much more compact */}
      <div className="bg-white w-full max-w-[540px] rounded-xl shadow-2xl overflow-hidden flex flex-col font-sans">
        
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-50 p-1.5 rounded-lg">
              <Settings2 className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h2 className="text-[15px] font-semibold text-gray-900 leading-tight">导入说明</h2>
              <p className="text-xs text-gray-500 mt-0.5">选择文件与图幅</p>
            </div>
          </div>
          <button className="text-gray-400 hover:text-gray-600 hover:bg-gray-50 p-1.5 rounded-lg transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 flex flex-col gap-5">
          
          {/* Word File */}
          <div className="flex items-center">
            <label className="w-20 shrink-0 text-[13px] font-medium text-gray-700">Word 文件</label>
            <div className="flex-1 border border-gray-200 rounded-lg p-1.5 flex items-center justify-between hover:border-gray-300 transition-colors">
              <div className="flex items-center gap-2.5 ml-1.5">
                <div className="bg-blue-600 rounded flex items-center justify-center w-6 h-6 text-white font-bold text-xs">
                  W
                </div>
                <span className="text-[13px] text-gray-600">未选择文件</span>
              </div>
              <button className="px-3 py-1.5 text-xs font-medium text-blue-600 hover:bg-blue-50 rounded-md transition-colors">
                更换
              </button>
            </div>
          </div>

          {/* Format */}
          <div className="flex items-start">
            <label className="w-20 shrink-0 text-[13px] font-medium text-gray-700 mt-2">图幅</label>
            <div className="flex-1 grid grid-cols-4 gap-2.5">
              {[
                { id: 'A1', label: 'A1', cols: '3列' },
                { id: 'A2', label: 'A2', cols: '3列' },
                { id: 'A3', label: 'A3', cols: '2列' },
              ].map((format) => (
                <button
                  key={format.id}
                  onClick={() => setSelectedFormat(format.id)}
                  className={`relative border rounded-lg p-2.5 flex flex-col items-center justify-center gap-1.5 transition-all duration-200 ${
                    selectedFormat === format.id 
                      ? 'border-blue-600 bg-blue-50 shadow-[0_0_0_1px_rgba(37,99,235,1)]' 
                      : 'border-gray-200 hover:border-gray-300 bg-white hover:bg-gray-50'
                  }`}
                >
                  <div className="w-7 h-7 border-[1.5px] border-current rounded-sm flex items-center justify-center gap-[2px]">
                    <div className="w-[1.5px] h-full bg-current opacity-30"></div>
                    <div className="w-[1.5px] h-full bg-current opacity-30"></div>
                  </div>
                  <div className="text-center mt-1">
                    <div className={`text-[13px] font-medium leading-none ${selectedFormat === format.id ? 'text-blue-900' : 'text-gray-900'}`}>
                      {format.label}
                    </div>
                    <div className={`text-[10px] mt-1 leading-none ${selectedFormat === format.id ? 'text-blue-600' : 'text-gray-500'}`}>
                      {format.cols}
                    </div>
                  </div>
                  {selectedFormat === format.id && (
                    <div className="absolute top-1.5 right-1.5 text-blue-600 bg-white rounded-full">
                      <CheckCircle2 className="w-3.5 h-3.5 fill-current text-white" />
                    </div>
                  )}
                </button>
              ))}
              
              {/* More Format Button */}
              <button className="border border-gray-200 hover:border-gray-300 bg-white hover:bg-gray-50 rounded-lg p-2.5 flex flex-col items-center justify-center gap-1.5 transition-all duration-200">
                <div className="w-7 h-7 border-[1.5px] border-gray-400 border-dashed rounded-sm flex items-center justify-center opacity-60">
                  <LayoutTemplate className="w-3.5 h-3.5 text-gray-500" />
                </div>
                <div className="text-center mt-1">
                  <div className="text-[13px] font-medium text-gray-900 leading-none">更多</div>
                  <div className="text-[10px] text-gray-500 mt-1 leading-none">···</div>
                </div>
              </button>
            </div>
          </div>

          {/* Unit Scale - Simplified */}
          <div className="flex items-center">
            <label className="w-20 shrink-0 text-[13px] font-medium text-gray-700">单位比例</label>
            <div className="flex-1 flex gap-2">
              {['1x', '100x', '1000x'].map((mult) => (
                <button 
                  key={mult}
                  onClick={() => setScale(mult)}
                  className={`flex-1 py-1.5 text-[13px] font-medium rounded-md transition-colors ${
                    scale === mult 
                      ? 'bg-blue-600 text-white shadow-sm' 
                      : 'bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200'
                  }`}
                >
                  {mult}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-5">
            <div className="flex items-center gap-1.5 text-blue-600 text-[13px] font-medium">
              <span className="w-4 h-4 rounded-full bg-blue-100 flex items-center justify-center text-[10px]">1</span>
              选择
            </div>
            <div className="flex items-center gap-1.5 text-gray-400 text-[13px] font-medium">
              <span className="w-4 h-4 rounded-full border border-gray-300 flex items-center justify-center text-[10px]">2</span>
              点位置
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button className="px-4 py-1.5 text-[13px] font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-200/50 rounded-lg transition-colors">
              取消
            </button>
            <button className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-[13px] font-medium rounded-lg shadow-sm shadow-blue-600/20 transition-colors flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" />
              在图纸中点位置
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
